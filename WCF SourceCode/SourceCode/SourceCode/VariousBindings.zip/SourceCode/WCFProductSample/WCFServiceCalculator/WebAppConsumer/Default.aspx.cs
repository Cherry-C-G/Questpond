﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebAppConsumer
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            CalculateCost.IServiceCalculateCost ICost = new CalculateCost.ServiceCalculateCostClient();
            CalculateCost.ProductData objProductData = new CalculateCost.ProductData();
            objProductData.ProductName = "Shirts";
            objProductData.ProductQuantity = 4;
            objProductData.PerProductCost = 200;
            Response.Write(ICost.getTotalCost(objProductData));
        }
    }
}
