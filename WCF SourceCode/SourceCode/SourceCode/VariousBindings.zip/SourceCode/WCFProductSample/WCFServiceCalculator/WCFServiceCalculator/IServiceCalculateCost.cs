﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCFServiceCalculator
{
    // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.
    [ServiceContract]
    public interface IServiceCalculateCost
    {

        [OperationContract]
        string getTotalCost(ProductData objProductData);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class ProductData
    {
        private int _intProductQty;
        private double _dblPerProductCost;
        private string _strProductName;

        [DataMember]
        public int ProductQuantity
        {
            get { return _intProductQty; }
            set { _intProductQty = value; }
        }
        [DataMember]
        public double PerProductCost
        {
            get { return _dblPerProductCost; }
            set { _dblPerProductCost = value; }
        }
        [DataMember]
        public string ProductName
        {
            get { return _strProductName; }
            set { _strProductName = value; }
        }
    }
}
